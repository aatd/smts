self.__precacheManifest = [
  {
    "revision": "545006940e872abd7608",
    "url": "/css/app.27be58c5.css"
  },
  {
    "revision": "545006940e872abd7608",
    "url": "/js/app.5eb823ae.js"
  },
  {
    "revision": "2ec9baf6c8259d74f50c",
    "url": "/css/chunk-vendors.ddf5493f.css"
  },
  {
    "revision": "2ec9baf6c8259d74f50c",
    "url": "/js/chunk-vendors.2691b056.js"
  },
  {
    "revision": "8224e0160e362e117cbe00495919e2af",
    "url": "/fonts/nucleo-icons.8224e016.eot"
  },
  {
    "revision": "b0dc05d015e91e7d28d79cd0056fe555",
    "url": "/fonts/nucleo-icons.b0dc05d0.ttf"
  },
  {
    "revision": "ff208b8d733e61a630992ee2b72c9c1c",
    "url": "/fonts/nucleo-icons.ff208b8d.woff2"
  },
  {
    "revision": "dc0cdfac3187d5fe800b249201cdf9b0",
    "url": "/img/nucleo-icons.dc0cdfac.svg"
  },
  {
    "revision": "497ee58b4bc28eb6d6c41acefe3feb36",
    "url": "/index.html"
  },
  {
    "revision": "996d8248f580f8e26e6c45c67da9b5a6",
    "url": "/favicon.png"
  },
  {
    "revision": "a9615bac158705203261e8348f574cc8",
    "url": "/img/faces/face-0.jpg"
  },
  {
    "revision": "a9615bac158705203261e8348f574cc8",
    "url": "/img/default-avatar.png"
  },
  {
    "revision": "0e953b1ea6d6e3addd7210e9c7c420a7",
    "url": "/img/faces/face-2.jpg"
  },
  {
    "revision": "99e58416b89637502b40ac8350eed85a",
    "url": "/img/faces/face-1.jpg"
  },
  {
    "revision": "ce7a6b79aa55041f7ae36f6ce22231fe",
    "url": "/img/faces/face-3.jpg"
  },
  {
    "revision": "4b87e628f4ef9988718860890b2a682f",
    "url": "/img/faces/face-6.jpg"
  },
  {
    "revision": "4ab22eca4053c14a34e4bdb6390deae9",
    "url": "/img/faces/face-5.jpg"
  },
  {
    "revision": "be74132f42ae1d3502f9a9b9fff68ac1",
    "url": "/Dashboard.PNG"
  },
  {
    "revision": "0b68eb8f1cde1fc9987a9196df05b96a",
    "url": "/img/faces/face-4.jpg"
  },
  {
    "revision": "bf1684a30a86ba1b222aab3acff16356",
    "url": "/img/faces/face-7.jpg"
  },
  {
    "revision": "43b98081492ac3bcb4a1fac6cf709403",
    "url": "/img/faces/tim_vector.jpe"
  },
  {
    "revision": "0ec8f86a54dce32152eaa33e932b9c97",
    "url": "/img/loading-bubbles.svg"
  },
  {
    "revision": "d27fbc90c2e644dfdc9765640dc713b9",
    "url": "/img/mask.png"
  },
  {
    "revision": "d124183abb725f6a4adf9d916388ebf3",
    "url": "/img/logo.png"
  },
  {
    "revision": "44bf13a71a4db6e15913fe8af9296711",
    "url": "/img/tim_80x80.png"
  },
  {
    "revision": "c2a605fbc0e687b2e1b4b90a7c445cdd",
    "url": "/img/vue-logo.png"
  },
  {
    "revision": "f575a04ebbb31b5798a4c54783e745a2",
    "url": "/img/new_logo.png"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "b985ae9ede51b8d67459c8bfc9086546",
    "url": "/img/bicycles/b-1.jpg"
  },
  {
    "revision": "c9242ad91aeb332f5f2985d9d67ec63c",
    "url": "/img/bg.jpg"
  }
];